from pdftostring.src.pdf2str.functions import *

#texto = pdf_to_str(r'C:\Users\bruno\Desktop\Scripts\9. LLMs\7. ChatGPT passa na OAB\5. Provas anteriores\35 a 40\Provas\2023-40.pdf', 2, 2, progress=False)

#print(texto[:100])

pdf_to_txt(r'C:\Users\bruno\Desktop\Scripts\9. LLMs\7. ChatGPT passa na OAB\5. Provas anteriores\35 a 40\Provas\2023-40.pdf')