# pdftostring

This package was made to make it easier to convert PDF files to strings and to .txt.